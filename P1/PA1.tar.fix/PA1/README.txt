To compile the program, type 'make' in the same directory as the Makefile and the source code.
This will generate an executable called modeltoworld

Then run the program like ./modeltoworld driver0x.txt
passing in the name of the driver file. This will then generate an output directory matching the input file's name with the output .obj files
